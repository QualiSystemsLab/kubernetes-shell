class DeployedAppAdditionalDataKeys(object):
    NAMESPACE = 'namespace'
    REPLICAS = 'replicas'
    WAIT_FOR_REPLICAS_TO_BE_READY = 'wait_for_replicas_to_be_ready'
